// src/background.ts
var API_BASE = "https://eficac-ia.vercel.app";
var STATE_KEY = "eficacia_active_task";
var STEP_ALARM = "eficacia_step";
var WATCHDOG_ALARM = "eficacia_watchdog";
function getState() {
  return new Promise(
    (r) => chrome.storage.local.get(STATE_KEY, (s) => r(s[STATE_KEY] ?? null))
  );
}
function saveState(state) {
  return new Promise((r) => chrome.storage.local.set({ [STATE_KEY]: state }, r));
}
function clearState() {
  return new Promise((r) => chrome.storage.local.remove([STATE_KEY], r));
}
function scheduleStep(delayMs) {
  chrome.alarms.clear(STEP_ALARM, () => {
    chrome.alarms.create(STEP_ALARM, { when: Date.now() + Math.max(delayMs, 500) });
  });
}
function ensureWatchdogAlarm() {
  chrome.alarms.get(WATCHDOG_ALARM, (existing) => {
    if (!existing) {
      chrome.alarms.create(WATCHDOG_ALARM, { periodInMinutes: 1 });
    }
  });
}
var _pingActive = false;
function startPingLoop(tabId) {
  if (_pingActive) return;
  _pingActive = true;
  const tick = async () => {
    if (!_pingActive) return;
    const state = await getState();
    if (!state?.active) {
      _pingActive = false;
      return;
    }
    chrome.tabs.sendMessage(tabId, { type: "CMD_PING" }).catch(() => {
    });
    setTimeout(tick, 5e3);
  };
  setTimeout(tick, 5e3);
}
function stopPingLoop() {
  _pingActive = false;
}
async function advance() {
  const state = await getState();
  if (!state?.active) {
    console.log("[EficacIA BG] advance() \u2014 no active state, stopping");
    return;
  }
  const { phase, tabId, leads, limit } = state;
  console.log(`[EficacIA BG] advance() phase=${phase} leads=${leads.length}/${limit} tab=${tabId}`);
  switch (phase) {
    case "SCROLL":
      chrome.tabs.sendMessage(tabId, { type: "CMD_SCROLL", payload: { platform: state.platform } }).catch(async (err) => {
        console.error("[EficacIA BG] CMD_SCROLL failed, injecting content script:", err);
        await injectContentScript(tabId);
        scheduleStep(2e3);
      });
      break;
    case "WAIT_SCROLL": {
      const delay = 4e3 + Math.random() * 2e3;
      console.log(`[EficacIA BG] WAIT_SCROLL: ${Math.round(delay / 1e3)}s before extract`);
      state.phase = "EXTRACT";
      await saveState(state);
      scheduleStep(delay);
      break;
    }
    case "EXTRACT":
      chrome.tabs.sendMessage(tabId, { type: "CMD_EXTRACT", payload: { platform: state.platform } }).catch((err) => {
        console.error("[EficacIA BG] CMD_EXTRACT failed:", err);
        scheduleStep(3e3);
      });
      break;
    case "NEXT_PAGE":
      chrome.tabs.sendMessage(tabId, { type: "CMD_NEXT_PAGE", payload: { platform: state.platform } }).catch((err) => {
        console.error("[EficacIA BG] CMD_NEXT_PAGE failed:", err);
        scheduleStep(3e3);
      });
      break;
    case "WAIT_NEXT": {
      const delay = 5e3 + Math.random() * 3e3;
      console.log(`[EficacIA BG] WAIT_NEXT: ${Math.round(delay / 1e3)}s for page to render`);
      state.phase = "SCROLL";
      await saveState(state);
      scheduleStep(delay);
      break;
    }
    case "ANTI_BOT_BREAK": {
      const delay = 3e4 + Math.random() * 15e3;
      console.log(`[EficacIA BG] ANTI_BOT_BREAK: ${Math.round(delay / 1e3)}s`);
      chrome.runtime.sendMessage({
        type: "SCRAPING_PROGRESS",
        payload: {
          progress: Math.min(leads.length / limit * 100, 99),
          current: leads.length,
          limit,
          statusText: "\u23F8 Pausa anti-bot..."
        }
      }).catch(() => {
      });
      state.phase = "NEXT_PAGE";
      await saveState(state);
      scheduleStep(delay);
      break;
    }
    case "SUBMIT":
      await doSubmit(state);
      break;
  }
}
async function onExtractDone(newLeads) {
  const state = await getState();
  if (!state?.active) return;
  console.log(`[EficacIA BG] onExtractDone: +${newLeads.length} leads`);
  if (newLeads.length === 0) {
    state.consecutiveEmptyPages++;
    console.warn(`[EficacIA BG] Empty page #${state.consecutiveEmptyPages}`);
  } else {
    state.consecutiveEmptyPages = 0;
  }
  if (state.consecutiveEmptyPages >= 3) {
    console.warn("[EficacIA BG] 3 consecutive empty pages \u2014 submitting what we have");
    state.phase = "SUBMIT";
    await saveState(state);
    await advance();
    return;
  }
  const seen = new Set(state.leads.map((l) => l.linkedin_url));
  for (const lead of newLeads) {
    if (state.leads.length >= state.limit) break;
    if (lead.linkedin_url && !seen.has(lead.linkedin_url)) {
      seen.add(lead.linkedin_url);
      state.leads.push(lead);
    }
  }
  state.lastActivityAt = Date.now();
  sendProgressFromState(state);
  console.log(`[EficacIA BG] Progress: ${state.leads.length}/${state.limit}`);
  if (state.leads.length >= state.limit) {
    state.phase = "SUBMIT";
    await saveState(state);
    await advance();
    return;
  }
  state.pageCount++;
  const interDelay = 3500 + Math.random() * 3500;
  state.phase = state.pageCount % 4 === 0 ? "ANTI_BOT_BREAK" : "NEXT_PAGE";
  await saveState(state);
  scheduleStep(interDelay);
}
async function onNextPageDone(moved) {
  const state = await getState();
  if (!state?.active) return;
  if (!moved) {
    console.log("[EficacIA BG] No more pages \u2014 submitting");
    state.phase = "SUBMIT";
    await saveState(state);
    await advance();
    return;
  }
  state.phase = "WAIT_NEXT";
  await saveState(state);
  await advance();
}
async function doSubmit(state) {
  console.log(`[EficacIA BG] Submitting ${state.leads.length} leads...`);
  stopPingLoop();
  try {
    await submitLeads(state.campaign_id, state.leads, state.token, state.backendUrl, state.platform);
    chrome.runtime.sendMessage({ type: "SCRAPING_FINISHED" }).catch(() => {
    });
  } catch (err) {
    console.error("[EficacIA BG] Submit error:", err);
    chrome.runtime.sendMessage({
      type: "SCRAPING_ERROR",
      payload: { error: err.message || "Error al enviar leads al servidor" }
    }).catch(() => {
    });
  } finally {
    await clearState();
  }
}
function sendProgressFromState(state) {
  const pct = Math.min(state.leads.length / state.limit * 100, 100);
  chrome.runtime.sendMessage({
    type: "SCRAPING_PROGRESS",
    payload: { progress: pct, current: state.leads.length, limit: state.limit }
  }).catch(() => {
  });
}
async function injectContentScript(tabId) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["assets/content.js"]
    });
    console.log(`[EficacIA BG] Content script injected into tab ${tabId}`);
  } catch (err) {
    console.error("[EficacIA BG] injection failed:", err);
  }
}
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === STEP_ALARM) {
    await advance();
    return;
  }
  if (alarm.name === WATCHDOG_ALARM) {
    const state = await getState();
    if (!state?.active) return;
    const staleMs = Date.now() - (state.lastActivityAt ?? 0);
    console.log(`[EficacIA BG] Watchdog: stale=${Math.round(staleMs / 1e3)}s phase=${state.phase}`);
    if (staleMs > 12e4) {
      console.warn("[EficacIA BG] Watchdog: stalled 2 min, re-advancing");
      await advance();
    }
  }
});
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const fromTabId = sender.tab?.id;
  switch (message.type) {
    case "START_SCRAPING": {
      (async () => {
        const { campaign_id, limit, token, backendUrl, tabId, platform } = message.payload;
        const targetTabId = tabId ?? fromTabId;
        if (!targetTabId) {
          chrome.runtime.sendMessage({
            type: "SCRAPING_ERROR",
            payload: { error: "No se encontr\xF3 la pesta\xF1a activa." }
          }).catch(() => {
          });
          sendResponse({ ok: false });
          return;
        }
        await injectContentScript(targetTabId);
        const state = {
          active: true,
          platform: platform ?? await detectPlatformForTab(targetTabId),
          campaign_id,
          limit,
          token,
          backendUrl,
          leads: [],
          phase: "SCROLL",
          pageCount: 0,
          consecutiveEmptyPages: 0,
          tabId: targetTabId,
          lastActivityAt: Date.now()
        };
        await saveState(state);
        startPingLoop(targetTabId);
        ensureWatchdogAlarm();
        scheduleStep(1200);
        console.log(`[EficacIA BG] START_SCRAPING \u2014 tab=${targetTabId} platform=${state.platform} limit=${limit}`);
        sendResponse({ ok: true });
      })();
      return true;
    }
    case "STOP_SCRAPING": {
      stopPingLoop();
      chrome.alarms.clear(STEP_ALARM);
      getState().then((state) => {
        if (state?.tabId) {
          chrome.tabs.sendMessage(state.tabId, { type: "STOP_SCRAPING" }).catch(() => {
          });
        }
      });
      clearState().then(() => {
        chrome.runtime.sendMessage({ type: "SCRAPING_STOPPED" }).catch(() => {
        });
      });
      break;
    }
    case "SCROLL_DONE": {
      (async () => {
        const state = await getState();
        if (!state?.active) return;
        state.phase = "WAIT_SCROLL";
        state.lastActivityAt = Date.now();
        await saveState(state);
        await advance();
      })();
      break;
    }
    case "EXTRACT_DONE": {
      onExtractDone(message.payload?.leads ?? []);
      break;
    }
    case "NEXT_PAGE_DONE": {
      onNextPageDone(message.payload?.moved ?? false);
      break;
    }
    case "CONTENT_READY": {
      (async () => {
        const state = await getState();
        if (!state?.active) return;
        if (fromTabId !== state.tabId) return;
        console.log(`[EficacIA BG] CONTENT_READY from tab ${fromTabId}, phase=${state.phase}`);
        if (state.phase === "SCROLL" || state.phase === "EXTRACT" || state.phase === "NEXT_PAGE") {
          scheduleStep(1500);
        }
      })();
      break;
    }
    case "PONG": {
      break;
    }
    case "SUBMIT_LEADS": {
      const { campaign_id, leads, token, backendUrl, source } = message.payload;
      submitLeads(campaign_id, leads, token, backendUrl, source).then(() => chrome.runtime.sendMessage({ type: "SCRAPING_FINISHED" }).catch(() => {
      })).catch(
        (err) => chrome.runtime.sendMessage({
          type: "SCRAPING_ERROR",
          payload: { error: err.message || "Error al enviar leads" }
        }).catch(() => {
        })
      );
      return true;
    }
  }
});
async function detectPlatformForTab(tabId) {
  try {
    const tab = await chrome.tabs.get(tabId);
    return (tab.url ?? "").includes("apollo.io") ? "apollo" : "sales_navigator";
  } catch {
    return "sales_navigator";
  }
}
chrome.runtime.onInstalled.addListener(() => {
  console.log("EficacIA Extension v2.0 Installed (Background State Machine)");
  ensureWatchdogAlarm();
});
chrome.runtime.onStartup.addListener(ensureWatchdogAlarm);
async function submitLeads(campaign_id, leads, token, backendUrl, source) {
  console.log(`[EficacIA Background] Submitting ${leads.length} leads (source: ${source ?? "extension"}) to ${backendUrl}...`);
  const baseUrl = backendUrl?.startsWith("http") ? backendUrl : API_BASE;
  const response = await fetch(`${baseUrl}/api/linkedin/bulk-import`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`
    },
    body: JSON.stringify({
      type: "extension",
      campaign_id,
      leads,
      ...source ? { source } : {}
    })
  });
  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(errorData.message || `Error del servidor: ${response.status}`);
  }
  console.log("[EficacIA Background] Bulk import successful!");
}
