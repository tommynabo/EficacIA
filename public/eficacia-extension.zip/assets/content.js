// src/content.ts
var _stopped = false;
var _cmdInFlight = false;
chrome.runtime.onMessage.addListener((message, _sender, _sendResponse) => {
  console.log("[EficacIA v2] Message received:", message.type);
  switch (message.type) {
    case "CMD_SCROLL": {
      if (_stopped) return;
      if (_cmdInFlight) {
        console.log("[EficacIA v2] CMD_SCROLL ignored \u2014 command already in flight");
        return;
      }
      _cmdInFlight = true;
      humanScrollDown().then(() => chrome.runtime.sendMessage({ type: "SCROLL_DONE" })).catch((err) => console.error("[EficacIA v2] CMD_SCROLL error:", err)).finally(() => {
        _cmdInFlight = false;
      });
      break;
    }
    case "CMD_EXTRACT": {
      if (_stopped) return;
      const env = detectEnvironment();
      const leads = env === "apollo" ? extractApolloLeads() : extractLinkedInLeadsFromPage();
      chrome.runtime.sendMessage({ type: "EXTRACT_DONE", payload: { leads } }).catch(() => {
      });
      break;
    }
    case "CMD_NEXT_PAGE": {
      if (_stopped) {
        chrome.runtime.sendMessage({ type: "NEXT_PAGE_DONE", payload: { moved: false } }).catch(() => {
        });
        return;
      }
      if (_cmdInFlight) return;
      _cmdInFlight = true;
      const env = detectEnvironment();
      const nextFn = env === "apollo" ? goToNextApolloPage : goToNextLinkedInPage;
      nextFn().then((moved) => chrome.runtime.sendMessage({ type: "NEXT_PAGE_DONE", payload: { moved } })).catch((err) => {
        console.error("[EficacIA v2] CMD_NEXT_PAGE error:", err);
        chrome.runtime.sendMessage({ type: "NEXT_PAGE_DONE", payload: { moved: false } }).catch(() => {
        });
      }).finally(() => {
        _cmdInFlight = false;
      });
      break;
    }
    case "CMD_PING": {
      chrome.runtime.sendMessage({ type: "PONG" }).catch(() => {
      });
      break;
    }
    case "STOP_SCRAPING": {
      console.log("[EficacIA v2] STOP_SCRAPING \u2014 halting");
      _stopped = true;
      _cmdInFlight = false;
      break;
    }
    case "RESUME_IF_STALLED": {
      if (!_stopped) {
        chrome.runtime.sendMessage({ type: "CONTENT_READY", payload: { url: window.location.href } }).catch(() => {
        });
      }
      break;
    }
  }
});
(function notifyOnLoad() {
  const env = detectEnvironment();
  console.log(`[EficacIA v2] notifyOnLoad \u2014 env: ${env} | url: ${window.location.href}`);
  const doNotify = () => {
    _stopped = false;
    chrome.runtime.sendMessage({
      type: "CONTENT_READY",
      payload: { url: window.location.href }
    }).catch(() => {
    });
  };
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => setTimeout(doNotify, 800));
  } else {
    setTimeout(doNotify, 800);
  }
})();
function detectEnvironment() {
  return window.location.hostname.includes("apollo.io") ? "apollo" : "sales_navigator";
}
function extractLinkedInLeadsFromPage() {
  const leads = [];
  const listItems = document.querySelectorAll("li.artdeco-list__item, .search-results__result-item");
  console.log(`[EficacIA v2] LinkedIn: scanning ${listItems.length} list items`);
  listItems.forEach((item, itemIdx) => {
    try {
      let linkedin_url = item.querySelector('a[href*="/sales/lead/"]')?.href || item.querySelector('[data-anonymize="person-name"]')?.closest("a")?.href || item.querySelector('a[href*="/in/"]')?.href || "";
      if (!linkedin_url) {
        const dataId = item.getAttribute("data-id") || item.getAttribute("data-p-id") || item.querySelector("[data-id]")?.getAttribute("data-id") || item.querySelector("[data-p-id]")?.getAttribute("data-p-id") || "";
        if (dataId) linkedin_url = `https://www.linkedin.com/sales/lead/${dataId}/`;
      }
      if (!linkedin_url) {
        const html = item.innerHTML;
        const salesLeadMatch = html.match(/\/sales\/lead\/(ACwA[A-Za-z0-9_-]{6,})[^"'\\s]*/);
        if (salesLeadMatch) {
          linkedin_url = `https://www.linkedin.com/sales/lead/${salesLeadMatch[1]}/`;
          console.log(`[EficacIA v2] Item[${itemIdx}]: URL recovered via innerHTML regex: ${linkedin_url}`);
        }
      }
      if (!linkedin_url) {
        const html = item.innerHTML;
        const inMatch = html.match(/linkedin\.com\/in\/([A-Za-z0-9_%-]+)/);
        if (inMatch) {
          linkedin_url = `https://www.linkedin.com/in/${inMatch[1]}/`;
          console.log(`[EficacIA v2] Item[${itemIdx}]: /in/ URL recovered via innerHTML regex`);
        }
      }
      if (!linkedin_url) {
        console.log(`[EficacIA v2] Item[${itemIdx}]: No URL found. Skipping.`);
        return;
      }
      if (linkedin_url.includes("?")) linkedin_url = linkedin_url.split("?")[0];
      if (!linkedin_url.endsWith("/")) linkedin_url += "/";
      const personNameEl = item.querySelector('[data-anonymize="person-name"]');
      let rawName = personNameEl?.textContent?.trim() || item.getAttribute("data-name") || "";
      if (!rawName) {
        const profileAnchors = Array.from(
          item.querySelectorAll('a[href*="/sales/lead/"], a[href*="/in/"]')
        );
        for (const a of profileAnchors) {
          const text = a.textContent?.trim() || "";
          if (text.length > 0) {
            rawName = text;
            break;
          }
        }
      }
      if (!rawName) {
        rawName = item.textContent?.split("\n")[0]?.trim() || "";
      }
      rawName = rawName.replace(/est[áa] disponible|Añadir a la selección|Guardar/gi, "").trim();
      const fullName = rawName.split("\n")[0]?.trim() || "";
      if (!fullName) {
        console.log(`[EficacIA v2] Item[${itemIdx}]: Could not extract name. Skipping.`);
        return;
      }
      const nameParts = fullName.split(/\s+/).filter(Boolean);
      let first_name = nameParts[0] || "";
      let last_name = nameParts.slice(1).join(" ") || "";
      const allText = item.textContent || "";
      const lines = allText.split("\n").map((s) => s.trim()).filter(Boolean);
      const garbageWords = [
        "conectar",
        "mensaje",
        "guardar",
        "connect",
        "message",
        "save",
        "ver perfil",
        "view profile",
        "seguir",
        "follow",
        "invite",
        "invitar",
        "enviar mensaje",
        "send message",
        "m\xE1s",
        "more"
      ];
      const usefulLines = lines.filter((line) => {
        const lower = line.toLowerCase();
        if (lower.includes(fullName.toLowerCase())) return false;
        if (/(1st|2nd|3rd|degree|grado|out of network|fuera de la red|conexión|connection)/i.test(lower)) return false;
        if (garbageWords.includes(lower)) return false;
        if (line.length < 2) return false;
        return true;
      });
      let job_title = usefulLines[0] || "";
      let company = usefulLines[1] || "";
      let location = usefulLines[2] || "";
      first_name = first_name.substring(0, 200).trim();
      last_name = last_name.substring(0, 200).trim();
      job_title = job_title.substring(0, 200).trim();
      company = company.substring(0, 200).trim();
      location = location.substring(0, 200).trim();
      console.log(
        `[EficacIA v2] Item[${itemIdx}]: \u2713 ${first_name} ${last_name} | ${job_title} @ ${company} | ${linkedin_url}`
      );
      leads.push({ first_name, last_name, job_title, company, linkedin_url, location });
    } catch (e) {
      console.warn(`[EficacIA v2] LinkedIn item[${itemIdx}] parse error:`, e);
    }
  });
  return leads;
}
async function goToNextLinkedInPage() {
  const nextBtn = document.querySelector("button.artdeco-pagination__button--next") || document.querySelector('button[aria-label*="Next"]') || document.querySelector('button[aria-label*="Siguiente"]') || document.querySelector("button.search-results__pagination-next-button");
  if (!nextBtn || nextBtn.disabled) {
    console.log("[EficacIA v2] LinkedIn: next button not found or disabled");
    return false;
  }
  nextBtn.scrollIntoView({ block: "center" });
  await sleep(300);
  const previousFirstItem = document.querySelector("li.artdeco-list__item, .search-results__result-item");
  try {
    nextBtn.click();
  } catch {
    nextBtn.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true }));
  }
  await waitForLinkedInPageTransition(previousFirstItem);
  return true;
}
function waitForLinkedInPageTransition(previousFirstItem, timeoutMs = 18e3) {
  return new Promise((resolve) => {
    const done = () => {
      clearTimeout(timer);
      observer.disconnect();
      resolve();
    };
    const check = () => {
      const current = document.querySelector("li.artdeco-list__item, .search-results__result-item");
      if (!current) {
        done();
        return;
      }
      if (current !== previousFirstItem) {
        done();
        return;
      }
      if (previousFirstItem === null && current !== null) done();
    };
    const timer = setTimeout(() => {
      observer.disconnect();
      console.warn("[EficacIA v2] LinkedIn: page transition timed out");
      resolve();
    }, timeoutMs);
    const observer = new MutationObserver(check);
    observer.observe(document.body, { childList: true, subtree: true });
    check();
  });
}
function extractApolloLeads() {
  const links = document.querySelectorAll('a[href*="linkedin.com"]');
  console.log(`[EficacIA v2] Apollo: Found ${links.length} linkedin.com links on page`);
  const seen = /* @__PURE__ */ new Set();
  const leads = [];
  for (const anchor of links) {
    try {
      if (anchor.href.includes("/company/") || anchor.href.includes("/companies/")) continue;
      const match = anchor.href.match(/(https?:\/\/(?:www\.)?linkedin\.com\/(?:in|sales\/lead)\/[^/?#\s]+)/);
      if (!match) continue;
      const linkedin_url = match[1].replace(/\/$/, "") + "/";
      if (seen.has(linkedin_url)) continue;
      seen.add(linkedin_url);
      const row = anchor.closest(".zp_accordion_row") || anchor.closest(".zp_baseRow") || anchor.closest("tr") || anchor.closest('[role="row"]') || anchor.closest('div[class*="Row"]') || climbToRowContainer(anchor);
      if (!row) continue;
      const lead = extractLeadFromRow(row, linkedin_url);
      if (lead) {
        leads.push(lead);
        console.log(`[EficacIA v2] Apollo: ${lead.first_name} ${lead.last_name} | ${lead.job_title} @ ${lead.company}`);
      }
    } catch (e) {
      console.warn("[EficacIA v2] Apollo: Parse error for", anchor.href, e);
    }
  }
  console.log(`[EficacIA v2] Apollo: Total leads from page: ${leads.length}`);
  return leads;
}
function climbToRowContainer(anchor) {
  let candidate = anchor.parentElement;
  for (let depth = 0; depth < 12 && candidate; depth++) {
    const parent = candidate.parentElement;
    if (!parent) break;
    const siblings = Array.from(parent.children).filter((c) => c.tagName === candidate.tagName);
    if (siblings.length >= 3 && !["SPAN", "A", "BUTTON", "TD"].includes(candidate.tagName)) {
      const othersWithLinks = siblings.filter(
        (s) => s !== candidate && s.querySelector('a[href*="linkedin.com"]')
      );
      if (othersWithLinks.length >= 1) return candidate;
    }
    candidate = parent;
  }
  return null;
}
function extractLeadFromRow(row, linkedin_url) {
  const nameAnchor = row.querySelector('a[href*="/people/"], a[href*="/contacts/"]');
  let fullName = nameAnchor?.textContent?.trim() ?? "";
  if (!fullName) {
    for (const a of Array.from(row.querySelectorAll("a"))) {
      if (a.href.includes("linkedin.com") || a.href.includes("/companies/")) continue;
      const text = a.textContent?.trim() ?? "";
      const words = text.split(/\s+/).filter(Boolean);
      if (words.length >= 1 && words.length <= 5 && text.length > 2 && text.length < 60 && !/[@\d({]/.test(text.charAt(0))) {
        fullName = text;
        break;
      }
    }
  }
  if (!fullName) {
    const cellLike = row.querySelectorAll("td, > div");
    for (const cell of cellLike) {
      const text = (cell.textContent?.trim() ?? "").split("\n")[0].trim();
      if (text.length > 2 && text.length < 60 && /^[A-Z\u00C0-\u00DC]/.test(text) && !/[@\d]/.test(text.charAt(0))) {
        fullName = text;
        break;
      }
    }
  }
  const nameParts = (fullName || "").split(/\s+/).filter(Boolean);
  const first_name = nameParts[0] ?? "";
  const last_name = nameParts.slice(1).join(" ") ?? "";
  if (!first_name) return null;
  let cells = Array.from(row.querySelectorAll("td"));
  if (cells.length < 2) cells = Array.from(row.querySelectorAll(":scope > div"));
  let job_title = "";
  let company = "";
  const companyAnchor = row.querySelector('a[href*="/companies/"], a[data-cy="company-name-link"]');
  company = companyAnchor?.textContent?.trim() ?? "";
  if (cells.length >= 2) {
    let nameCellIdx = nameAnchor ? cells.findIndex((c) => c.contains(nameAnchor)) : -1;
    if (nameCellIdx < 0) nameCellIdx = cells.findIndex((c) => (c.textContent?.trim() ?? "").includes(first_name));
    if (nameCellIdx < 0) nameCellIdx = 0;
    job_title = cells[nameCellIdx + 1]?.textContent?.trim().split("\n")[0].trim() ?? "";
    if (!company) company = cells[nameCellIdx + 2]?.textContent?.trim().split("\n")[0].trim() ?? "";
  }
  let email;
  const allCells = cells.length > 0 ? cells : Array.from(row.querySelectorAll("td, > div"));
  for (const cell of allCells) {
    const text = cell.textContent?.trim() ?? "";
    if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(text)) {
      email = text;
      break;
    }
  }
  return { first_name, last_name, job_title, company, linkedin_url, location: "", email };
}
async function goToNextApolloPage() {
  window.scrollTo(0, document.body.scrollHeight);
  await sleep(1e3);
  const nextBtn = findApolloNextButton();
  if (!nextBtn) {
    console.log("[EficacIA v2] Apollo: next button not found");
    return false;
  }
  const previousUrl = window.location.href;
  const previousFirstRow = document.querySelector(
    'table tbody tr, [role="row"], .zp_accordion_row, .zp_baseRow'
  );
  nextBtn.click();
  await waitForApolloPageTransition(previousFirstRow, previousUrl);
  return true;
}
function findApolloNextButton() {
  const directSelectors = [
    'button[data-cy="next-page-button"]',
    'button[aria-label="next page"]',
    'button[aria-label="Next page"]',
    'button[aria-label="Next Page"]',
    'a[aria-label="next page"]',
    'button[title="Next page"]',
    'button[title="Next Page"]'
  ];
  for (const sel of directSelectors) {
    const btn = document.querySelector(sel);
    if (btn && !btn.hasAttribute("disabled") && btn.getAttribute("aria-disabled") !== "true") return btn;
  }
  const iconBtns = document.querySelectorAll(
    'button:has(i[class*="chevron-right"]), button:has(i[class*="arrow-right"]), button:has(svg[class*="right"]), .zp-button:has(.zp-icon-chevron-right)'
  );
  for (const btn of iconBtns) {
    if (!btn.disabled && btn.getAttribute("aria-disabled") !== "true") return btn;
  }
  const containers = document.querySelectorAll(
    '[class*="pagination"], [class*="Pagination"], [role="navigation"], [class*="pager"]'
  );
  for (const container of containers) {
    const buttons = [...container.querySelectorAll("button, a")];
    const nextLike = buttons.find((b) => {
      if (b.disabled || b.getAttribute("aria-disabled") === "true") return false;
      const text = b.textContent?.trim() ?? "";
      const label = (b.getAttribute("aria-label") ?? "").toLowerCase();
      const cls = (b.className ?? "").toLowerCase();
      return text === ">" || text === "\u203A" || text === "\xBB" || label.includes("next") || cls.includes("next");
    });
    if (nextLike) return nextLike;
    const last = [...buttons].reverse().find(
      (b) => !b.disabled && b.getAttribute("aria-disabled") !== "true"
    );
    if (last) return last;
  }
  const allButtons = document.querySelectorAll("button");
  for (const btn of allButtons) {
    if (btn.disabled || btn.getAttribute("aria-disabled") === "true") continue;
    const icon = btn.querySelector("i, svg");
    if (icon && /(right|forward|next)/i.test(icon.className)) return btn;
  }
  return null;
}
function waitForApolloPageTransition(previousFirstRow, previousUrl, timeoutMs = 2e4) {
  return new Promise((resolve) => {
    let settled = false;
    const done = async () => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      observer.disconnect();
      await waitForApolloRows();
      await sleep(800);
      resolve();
    };
    const check = () => {
      if (window.location.href !== previousUrl) {
        done();
        return;
      }
      const current = document.querySelector(
        'table tbody tr, [role="row"], .zp_accordion_row, .zp_baseRow'
      );
      if (!current) {
        done();
        return;
      }
      if (current !== previousFirstRow) done();
    };
    const timer = setTimeout(() => {
      if (!settled) {
        settled = true;
        observer.disconnect();
        console.warn("[EficacIA v2] Apollo: page transition timed out");
        sleep(1e3).then(resolve);
      }
    }, timeoutMs);
    const observer = new MutationObserver(check);
    observer.observe(document.body, { childList: true, subtree: true });
    sleep(400).then(check);
  });
}
function waitForApolloRows(timeoutMs = 2e4) {
  const isReady = () => !!document.querySelector('a[href*="linkedin.com"]') || !!document.querySelector("table tbody tr") || !!document.querySelector('[role="row"]') || !!document.querySelector('.zp_accordion_row, .zp_baseRow, [class*="Row"]');
  return new Promise((resolve) => {
    if (isReady()) {
      resolve();
      return;
    }
    const timer = setTimeout(() => {
      observer.disconnect();
      console.warn("[EficacIA v2] waitForApolloRows timed out");
      resolve();
    }, timeoutMs);
    const observer = new MutationObserver(() => {
      if (isReady()) {
        clearTimeout(timer);
        observer.disconnect();
        resolve();
      }
    });
    observer.observe(document.body, { childList: true, subtree: true });
  });
}
async function scrollApolloTable() {
  const container = document.querySelector('[class*="table_wrapper"], [class*="tableWrapper"], .infinite-scroll-component') ?? document.querySelector('main, [role="main"]') ?? document.documentElement;
  let prev = -1;
  let stable = 0;
  while (stable < 2) {
    const h = container.scrollHeight;
    container.scrollTop = h;
    window.scrollTo(0, document.body.scrollHeight);
    if (h === prev) {
      stable++;
    } else {
      stable = 0;
      prev = h;
    }
    await sleep(600);
  }
  await sleep(400);
}
function findScrollableContainer() {
  const byId = document.querySelector("#search-results-container");
  if (byId) return byId;
  const byAria = document.querySelector('[aria-label="Search results"]')?.parentElement;
  if (byAria) return byAria;
  const firstCard = document.querySelector("li.artdeco-list__item, .search-results__result-item");
  if (firstCard) {
    let el = firstCard.parentElement;
    while (el && el !== document.documentElement) {
      const { overflow, overflowY } = window.getComputedStyle(el);
      if (/(auto|scroll)/.test(overflow + overflowY) && el.scrollHeight > el.clientHeight) return el;
      el = el.parentElement;
    }
  }
  return document.documentElement;
}
async function humanScrollDown() {
  if (detectEnvironment() === "apollo") {
    await scrollApolloTable();
    return;
  }
  const container = findScrollableContainer();
  const isRoot = container === document.documentElement;
  console.log(
    `[EficacIA v2] Scrolling <${container.tagName} id="${container.id}" class="${container.className.slice(0, 60)}">`
  );
  if (isRoot) window.scrollTo(0, 0);
  else container.scrollTop = 0;
  await sleep(100);
  const totalHeight = () => isRoot ? document.documentElement.scrollHeight : container.scrollHeight;
  for (let step = 1; step <= 6; step++) {
    const target = Math.floor(totalHeight() * (step / 6));
    if (isRoot) window.scrollTo(0, target);
    else container.scrollTop = target;
    await sleep(80);
  }
  console.log("[EficacIA v2] \u2705 Scroll completo.");
}
function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
