// src/content.ts
var TASK_KEY = "eficacia_active_task";
function getTask() {
  return new Promise(
    (r) => chrome.storage.local.get(TASK_KEY, (s) => r(s[TASK_KEY] ?? null))
  );
}
function saveTask(task) {
  console.log(`[EficacIA MegaFix] Saving task to storage: ${task.leads.length} leads collected`);
  return new Promise((r) => chrome.storage.local.set({ [TASK_KEY]: task }, r));
}
function clearTask() {
  console.log("[EficacIA MegaFix] Clearing task from storage");
  return new Promise((r) => chrome.storage.local.remove([TASK_KEY], r));
}
var _running = false;
chrome.runtime.onMessage.addListener((message, _sender, _sendResponse) => {
  console.log("[EficacIA MegaFix] Message received:", message.type);
  if (message.type === "START_SCRAPING") {
    const { campaign_id, limit, token, backendUrl } = message.payload;
    const platform = detectEnvironment();
    console.log(`[EficacIA MegaFix] START_SCRAPING \u2014 platform: ${platform} | limit: ${limit} | campaign: ${campaign_id}`);
    const task = {
      active: true,
      platform,
      campaign_id,
      limit,
      token,
      backendUrl,
      leads: []
    };
    chrome.storage.local.set({ [TASK_KEY]: task }, () => {
      if (!_running) startScrapingProcess();
    });
  }
  if (message.type === "RESUME_IF_STALLED") {
    console.log("[EficacIA MegaFix] RESUME_IF_STALLED received, _running:", _running);
    if (!_running) startScrapingProcess();
  }
});
(function resumeOnLoad() {
  const env = detectEnvironment();
  console.log(`[EficacIA MegaFix] resumeOnLoad \u2014 env: ${env} | url: ${window.location.href}`);
  chrome.storage.local.get(TASK_KEY, (result) => {
    const task = result[TASK_KEY];
    if (!task?.active) {
      console.log("[EficacIA MegaFix] No active task in storage");
      return;
    }
    if (task.platform !== env) {
      console.log(`[EficacIA MegaFix] Task platform (${task.platform}) != env (${env}), skipping`);
      return;
    }
    console.log(`[EficacIA MegaFix] Active task found! ${task.leads.length}/${task.limit} leads. Waiting for DOM...`);
    const waitThenResume = () => {
      if (_running) return;
      const ready = env === "apollo" ? !!document.querySelector('a[href*="linkedin.com"]') || !!document.querySelector("table tbody tr") : !!document.querySelector("li.artdeco-list__item, .search-results__result-item");
      if (ready) {
        console.log("[EficacIA MegaFix] DOM ready \u2014 auto-resuming scraping");
        startScrapingProcess();
      } else {
        console.log("[EficacIA MegaFix] DOM not ready, retrying in 1s...");
        setTimeout(waitThenResume, 1e3);
      }
    };
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", () => setTimeout(waitThenResume, 1500));
    } else {
      setTimeout(waitThenResume, 1500);
    }
  });
})();
function detectEnvironment() {
  return window.location.hostname.includes("apollo.io") ? "apollo" : "sales_navigator";
}
async function startScrapingProcess() {
  if (_running) return;
  const task = await getTask();
  if (!task?.active) {
    console.log("[EficacIA MegaFix] startScrapingProcess: no active task, aborting");
    return;
  }
  _running = true;
  console.log(`[EficacIA MegaFix] \u2550\u2550\u2550 SCRAPING STARTED \u2550\u2550\u2550 platform: ${task.platform} | target: ${task.limit} | have: ${task.leads.length}`);
  try {
    if (task.platform === "apollo") {
      await runApolloScraper(task);
    } else {
      await runLinkedInScraper(task);
    }
    const finalTask = await getTask();
    if (!finalTask) return;
    console.log(`[EficacIA MegaFix] \u2550\u2550\u2550 SCRAPING COMPLETE \u2550\u2550\u2550 Submitting ${finalTask.leads.length} leads to backend`);
    chrome.runtime.sendMessage({
      type: "SUBMIT_LEADS",
      payload: {
        campaign_id: finalTask.campaign_id,
        leads: finalTask.leads,
        token: finalTask.token,
        backendUrl: finalTask.backendUrl,
        source: finalTask.platform
      }
    });
    await clearTask();
  } catch (error) {
    console.error("[EficacIA MegaFix] Scraping error:", error);
    chrome.runtime.sendMessage({
      type: "SCRAPING_ERROR",
      payload: { error: error.message }
    });
    await clearTask();
  } finally {
    _running = false;
  }
}
async function runLinkedInScraper(task) {
  console.log("[EficacIA MegaFix] runLinkedInScraper started");
  while (task.leads.length < task.limit) {
    await scrollToBottom();
    const pageLeads = extractLinkedInLeadsFromPage();
    console.log(`[EficacIA MegaFix] LinkedIn: found ${pageLeads.length} leads on current page`);
    const seen = new Set(task.leads.map((l) => l.linkedin_url));
    for (const lead of pageLeads) {
      if (task.leads.length >= task.limit) break;
      if (!seen.has(lead.linkedin_url)) {
        seen.add(lead.linkedin_url);
        task.leads.push(lead);
      }
    }
    await saveTask(task);
    sendProgress(task);
    console.log(`[EficacIA MegaFix] LinkedIn progress: ${task.leads.length}/${task.limit}`);
    if (task.leads.length >= task.limit) break;
    const movedToNext = await goToNextLinkedInPage();
    if (!movedToNext) {
      console.log("[EficacIA MegaFix] LinkedIn: No more pages available");
      break;
    }
  }
}
async function scrollToBottom() {
  const scrollEl = document.querySelector(".search-results__result-list") || document.scrollingElement || document.documentElement;
  let previousHeight = -1;
  let stableRounds = 0;
  while (stableRounds < 3) {
    const currentHeight = scrollEl.scrollHeight;
    window.scrollTo(0, currentHeight);
    if (currentHeight === previousHeight) {
      stableRounds++;
    } else {
      stableRounds = 0;
      previousHeight = currentHeight;
    }
    await sleep(stableRounds === 0 ? 800 : 400);
  }
  await sleep(1200);
}
function extractLinkedInLeadsFromPage() {
  const leads = [];
  const listItems = document.querySelectorAll("li.artdeco-list__item, .search-results__result-item");
  console.log(`[EficacIA MegaFix] LinkedIn: scanning ${listItems.length} list items`);
  listItems.forEach((item) => {
    try {
      const nameEl = item.querySelector('[data-anonymize="person-name"], .result-lockup__name a');
      const profileLink = item.querySelector('a[data-control-name="view_profile"], .result-lockup__name a');
      if (nameEl && profileLink) {
        const fullName = nameEl.textContent?.trim() || "";
        const parts = fullName.split(" ");
        const first_name = parts[0] || "";
        const last_name = parts.slice(1).join(" ") || "";
        const titleEl = item.querySelector('[data-anonymize="job-title"], .result-lockup__highlight-keyword');
        const companyEl = item.querySelector('[data-anonymize="company-name"], .result-lockup__position-company');
        const locationEl = item.querySelector('[data-anonymize="location"], .result-lockup__location');
        let linkedin_url = profileLink.href;
        if (linkedin_url.includes("?")) linkedin_url = linkedin_url.split("?")[0];
        leads.push({
          first_name,
          last_name,
          job_title: titleEl?.textContent?.trim() || "",
          company: companyEl?.textContent?.trim() || "",
          linkedin_url,
          location: locationEl?.textContent?.trim() || ""
        });
      }
    } catch (e) {
      console.warn("[EficacIA MegaFix] LinkedIn parse error:", e);
    }
  });
  return leads;
}
async function goToNextLinkedInPage() {
  const nextBtn = document.querySelector(".artdeco-pagination__button--next") || document.querySelector("button.search-results__pagination-next-button");
  if (!nextBtn || nextBtn.disabled) {
    console.log("[EficacIA MegaFix] LinkedIn: next button not found or disabled");
    return false;
  }
  console.log("[EficacIA MegaFix] LinkedIn: clicking Next page...");
  const previousFirstItem = document.querySelector("li.artdeco-list__item, .search-results__result-item");
  nextBtn.click();
  await waitForLinkedInPageTransition(previousFirstItem);
  return true;
}
function waitForLinkedInPageTransition(previousFirstItem, timeoutMs = 18e3) {
  return new Promise((resolve) => {
    const done = () => {
      clearTimeout(timer);
      observer.disconnect();
      sleep(1500).then(resolve);
    };
    const check = () => {
      const current = document.querySelector("li.artdeco-list__item, .search-results__result-item");
      if (!current) {
        done();
        return;
      }
      if (current !== previousFirstItem) {
        done();
        return;
      }
      if (previousFirstItem === null && current !== null) done();
    };
    const timer = setTimeout(() => {
      observer.disconnect();
      console.warn("[EficacIA MegaFix] LinkedIn: page transition timed out");
      sleep(4e3).then(resolve);
    }, timeoutMs);
    const observer = new MutationObserver(check);
    observer.observe(document.body, { childList: true, subtree: true });
    check();
  });
}
async function runApolloScraper(task) {
  console.log("[EficacIA MegaFix] runApolloScraper started \u2014 waiting for rows...");
  await waitForApolloRows();
  await sleep(2e3);
  console.log("[EficacIA MegaFix] Apollo rows detected, beginning extraction loop");
  while (task.leads.length < task.limit) {
    await scrollApolloTable();
    await sleep(700);
    const pageLeads = extractApolloLeads();
    console.log(`[EficacIA MegaFix] Apollo: extracted ${pageLeads.length} leads from current page`);
    const seen = new Set(task.leads.map((l) => l.linkedin_url).filter(Boolean));
    for (const lead of pageLeads) {
      if (task.leads.length >= task.limit) break;
      if (lead.linkedin_url && !seen.has(lead.linkedin_url)) {
        seen.add(lead.linkedin_url);
        task.leads.push(lead);
      }
    }
    await saveTask(task);
    sendProgress(task);
    console.log(`[EficacIA MegaFix] Apollo progress: ${task.leads.length}/${task.limit}`);
    if (task.leads.length >= task.limit) break;
    const moved = await goToNextApolloPage();
    if (!moved) {
      console.log("[EficacIA MegaFix] Apollo: No more pages available");
      break;
    }
  }
}
function waitForApolloRows(timeoutMs = 2e4) {
  const isReady = () => !!document.querySelector('a[href*="linkedin.com"]') || !!document.querySelector("table tbody tr") || !!document.querySelector('[role="row"]');
  return new Promise((resolve) => {
    if (isReady()) {
      console.log("[EficacIA MegaFix] Apollo rows already present");
      resolve();
      return;
    }
    const timer = setTimeout(() => {
      observer.disconnect();
      console.warn("[EficacIA MegaFix] waitForApolloRows timed out \u2014 proceeding anyway");
      resolve();
    }, timeoutMs);
    const observer = new MutationObserver(() => {
      if (isReady()) {
        clearTimeout(timer);
        observer.disconnect();
        console.log("[EficacIA MegaFix] Apollo rows appeared via MutationObserver");
        resolve();
      }
    });
    observer.observe(document.body, { childList: true, subtree: true });
  });
}
async function scrollApolloTable() {
  const container = document.querySelector('[class*="table_wrapper"], [class*="tableWrapper"], .infinite-scroll-component') ?? document.querySelector('main, [role="main"]') ?? document.documentElement;
  let prev = -1;
  let stable = 0;
  while (stable < 2) {
    const h = container.scrollHeight;
    container.scrollTop = h;
    window.scrollTo(0, document.body.scrollHeight);
    if (h === prev) {
      stable++;
    } else {
      stable = 0;
      prev = h;
    }
    await sleep(600);
  }
  await sleep(500);
}
function extractApolloLeads() {
  const links = document.querySelectorAll('a[href*="linkedin.com"]');
  console.log(`[EficacIA MegaFix] Apollo STEP 1: Found ${links.length} linkedin.com links on page`);
  const seen = /* @__PURE__ */ new Set();
  const leads = [];
  for (const anchor of links) {
    try {
      if (anchor.href.includes("/company/") || anchor.href.includes("/companies/")) continue;
      const match = anchor.href.match(/(https?:\/\/(?:www\.)?linkedin\.com\/(?:in|sales\/lead)\/[^/?#\s]+)/);
      if (!match) continue;
      const linkedin_url = match[1].replace(/\/$/, "") + "/";
      if (seen.has(linkedin_url)) continue;
      seen.add(linkedin_url);
      const row = anchor.closest("tr") || anchor.closest('[role="row"]') || climbToRowContainer(anchor);
      if (!row) {
        console.log(`[EficacIA MegaFix] Apollo STEP 2: No row container for ${linkedin_url}`);
        continue;
      }
      console.log(`[EficacIA MegaFix] Apollo STEP 2: Row found <${row.tagName}> for ${linkedin_url}`);
      const lead = extractLeadFromRow(row, linkedin_url);
      if (lead) {
        leads.push(lead);
        console.log(`[EficacIA MegaFix] Apollo STEP 3: Extracted: ${lead.first_name} ${lead.last_name} | ${lead.job_title} @ ${lead.company}`);
      }
    } catch (e) {
      console.warn("[EficacIA MegaFix] Apollo: Parse error for", anchor.href, e);
    }
  }
  console.log(`[EficacIA MegaFix] Apollo: Total leads from page: ${leads.length}`);
  return leads;
}
function climbToRowContainer(anchor) {
  let candidate = anchor.parentElement;
  for (let depth = 0; depth < 12 && candidate; depth++) {
    const parent = candidate.parentElement;
    if (!parent) break;
    const siblings = Array.from(parent.children).filter((c) => c.tagName === candidate.tagName);
    if (siblings.length >= 3 && !["SPAN", "A", "BUTTON", "TD"].includes(candidate.tagName)) {
      const othersWithLinks = siblings.filter(
        (s) => s !== candidate && s.querySelector('a[href*="linkedin.com"]')
      );
      if (othersWithLinks.length >= 1) {
        console.log(`[EficacIA MegaFix] Apollo: Fallback row found at depth ${depth} <${candidate.tagName}>`);
        return candidate;
      }
    }
    candidate = parent;
  }
  return null;
}
function extractLeadFromRow(row, linkedin_url) {
  const nameAnchor = row.querySelector('a[href*="/people/"], a[href*="/contacts/"]');
  let fullName = nameAnchor?.textContent?.trim() ?? "";
  if (!fullName) {
    for (const a of Array.from(row.querySelectorAll("a"))) {
      if (a.href.includes("linkedin.com") || a.href.includes("/companies/")) continue;
      const text = a.textContent?.trim() ?? "";
      const words = text.split(/\s+/).filter(Boolean);
      if (words.length >= 1 && words.length <= 5 && text.length > 2 && text.length < 60 && !/[@\d({]/.test(text.charAt(0))) {
        fullName = text;
        break;
      }
    }
  }
  if (!fullName) {
    for (const cell of row.querySelectorAll("td")) {
      const text = (cell.textContent?.trim() ?? "").split("\n")[0].trim();
      if (text.length > 2 && text.length < 60 && /^[A-Z\u00C0-\u00DC]/.test(text) && !/[@\d]/.test(text.charAt(0))) {
        fullName = text;
        break;
      }
    }
  }
  const nameParts = (fullName || "").split(/\s+/).filter(Boolean);
  const first_name = nameParts[0] ?? "";
  const last_name = nameParts.slice(1).join(" ") ?? "";
  if (!first_name) return null;
  const cells = Array.from(row.querySelectorAll("td"));
  let job_title = "";
  let company = "";
  const companyAnchor = row.querySelector('a[href*="/companies/"], a[data-cy="company-name-link"]');
  company = companyAnchor?.textContent?.trim() ?? "";
  if (cells.length >= 2) {
    let nameCellIdx = nameAnchor ? cells.findIndex((c) => c.contains(nameAnchor)) : -1;
    if (nameCellIdx < 0) {
      nameCellIdx = cells.findIndex((c) => (c.textContent?.trim() ?? "").includes(first_name));
    }
    if (nameCellIdx < 0) nameCellIdx = 0;
    job_title = cells[nameCellIdx + 1]?.textContent?.trim().split("\n")[0].trim() ?? "";
    if (!company) {
      company = cells[nameCellIdx + 2]?.textContent?.trim().split("\n")[0].trim() ?? "";
    }
  }
  let email;
  for (const cell of cells) {
    const text = cell.textContent?.trim() ?? "";
    if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(text)) {
      email = text;
      break;
    }
  }
  return { first_name, last_name, job_title, company, linkedin_url, location: "", email };
}
async function goToNextApolloPage() {
  const nextBtn = findApolloNextButton();
  if (!nextBtn) {
    console.log("[EficacIA MegaFix] Apollo: next button not found");
    return false;
  }
  console.log("[EficacIA MegaFix] Apollo: clicking Next page...");
  const previousUrl = window.location.href;
  const previousFirstRow = document.querySelector('table tbody tr, [role="row"]');
  nextBtn.click();
  await waitForApolloPageTransition(previousFirstRow, previousUrl);
  console.log("[EficacIA MegaFix] Apollo: page transition complete");
  return true;
}
function findApolloNextButton() {
  const byAttr = document.querySelector(
    'button[data-cy="next-page-button"], button[aria-label="next page"], button[aria-label="Next page"], a[aria-label="next page"], button[title="Next page"]'
  );
  if (byAttr && !byAttr.hasAttribute("disabled") && byAttr.getAttribute("aria-disabled") !== "true") {
    return byAttr;
  }
  const containers = document.querySelectorAll('[class*="pagination"], [class*="Pagination"], [role="navigation"]');
  for (const container of containers) {
    const buttons = [...container.querySelectorAll("button")];
    const nextLike = buttons.find((b) => {
      if (b.disabled || b.getAttribute("aria-disabled") === "true") return false;
      const text = b.textContent?.trim() ?? "";
      const label = (b.getAttribute("aria-label") ?? "").toLowerCase();
      return text === ">" || text === "\u203A" || text === "\xBB" || label.includes("next");
    });
    if (nextLike) return nextLike;
    const last = [...buttons].reverse().find(
      (b) => !b.disabled && b.getAttribute("aria-disabled") !== "true"
    );
    if (last) return last;
  }
  return null;
}
function waitForApolloPageTransition(previousFirstRow, previousUrl, timeoutMs = 2e4) {
  return new Promise((resolve) => {
    let settled = false;
    const done = async () => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      observer.disconnect();
      await waitForApolloRows();
      await sleep(800);
      resolve();
    };
    const check = () => {
      if (window.location.href !== previousUrl) {
        done();
        return;
      }
      const current = document.querySelector('table tbody tr, [role="row"]');
      if (!current) {
        done();
        return;
      }
      if (current !== previousFirstRow) done();
    };
    const timer = setTimeout(() => {
      if (!settled) {
        settled = true;
        observer.disconnect();
        console.warn("[EficacIA MegaFix] Apollo: page transition timed out");
        sleep(3e3).then(resolve);
      }
    }, timeoutMs);
    const observer = new MutationObserver(check);
    observer.observe(document.body, { childList: true, subtree: true });
    sleep(400).then(check);
  });
}
function sendProgress(task) {
  const pct = Math.min(task.leads.length / task.limit * 100, 100);
  chrome.runtime.sendMessage({
    type: "SCRAPING_PROGRESS",
    payload: {
      progress: pct,
      current: task.leads.length,
      limit: task.limit
    }
  });
}
function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
